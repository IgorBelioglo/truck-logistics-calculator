export type OperationType = 'Загрузка' | 'Разгрузка';
export type TripType = 'Груженый' | 'Порожний';

export interface TripSegment {
  id: string;
  date: string;
  startLocation: string;
  startOp: OperationType;
  endLocation: string;
  endOp: OperationType;
  tripType: TripType;
  distanceKm: number;
  notes?: string;
  startCoords?: [number, number]; // [lat, lng]
  endCoords?: [number, number];
}

export interface CalculationSettings {
  loadedRatePerKm: number; // e.g. 80 rubles / km
  emptyRatePerKm: number; // e.g. 50 rubles / km
  fuelConsumptionPer100Km: number; // e.g. 32 L / 100km
  fuelPricePerLiter: number; // e.g. 68 rubles / L
  currency: string; // '₽', '$', '₸', 'Br'
}

export interface TripSummary {
  totalKm: number;
  loadedKm: number;
  emptyKm: number;
  loadedPercent: number;
  emptyPercent: number;
  estimatedFuelLiters: number;
  estimatedFuelCost: number;
  estimatedEarnings: number;
}
