import React, { useState } from 'react';
import { OperationType, TripSegment, TripType } from '../types/logistics';
import {
  Copy,
  Check,
  FileSpreadsheet,
  Download,
  Plus,
  Trash2,
  Edit2,
  ArrowUp,
  ArrowDown,
  Printer,
  Package,
  Box,
  Truck,
  RotateCcw,
} from 'lucide-react';
import { generateCsvReport, generateMarkdownReport, generateTsvReport } from '../utils/geoUtils';

interface TripTableProps {
  segments: TripSegment[];
  onUpdateSegment: (segment: TripSegment) => void;
  onDeleteSegment: (id: string) => void;
  onAddSegment: () => void;
  onMoveSegment: (index: number, direction: 'up' | 'down') => void;
  onOpenEditModal: (segment: TripSegment) => void;
}

export const TripTable: React.FC<TripTableProps> = ({
  segments,
  onUpdateSegment,
  onDeleteSegment,
  onAddSegment,
  onMoveSegment,
  onOpenEditModal,
}) => {
  const [copiedMd, setCopiedMd] = useState(false);
  const [copiedExcel, setCopiedExcel] = useState(false);
  const [editingDistanceId, setEditingDistanceId] = useState<string | null>(null);
  const [tempDistance, setTempDistance] = useState<string>('');

  const loadedKm = segments
    .filter((s) => s.tripType === 'Груженый')
    .reduce((acc, curr) => acc + (curr.distanceKm || 0), 0);

  const emptyKm = segments
    .filter((s) => s.tripType === 'Порожний')
    .reduce((acc, curr) => acc + (curr.distanceKm || 0), 0);

  const totalKm = loadedKm + emptyKm;

  // Copy Markdown
  const handleCopyMarkdown = async () => {
    const md = generateMarkdownReport(segments);
    await navigator.clipboard.writeText(md);
    setCopiedMd(true);
    setTimeout(() => setCopiedMd(false), 2000);
  };

  // Copy TSV for 1-click paste into Excel/Google Sheets
  const handleCopyExcel = async () => {
    const tsv = generateTsvReport(segments);
    await navigator.clipboard.writeText(tsv);
    setCopiedExcel(true);
    setTimeout(() => setCopiedExcel(false), 2000);
  };

  // Download CSV
  const handleDownloadCsv = () => {
    const csv = generateCsvReport(segments);
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', `рейсы_пробег_дальнобой_${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // Quick distance inline editing
  const handleStartEditDistance = (s: TripSegment) => {
    setEditingDistanceId(s.id);
    setTempDistance(s.distanceKm.toString());
  };

  const handleSaveDistance = (s: TripSegment) => {
    const parsed = parseInt(tempDistance, 10);
    if (!isNaN(parsed) && parsed >= 0) {
      onUpdateSegment({ ...s, distanceKm: parsed });
    }
    setEditingDistanceId(null);
  };

  // Quick toggle trip type
  const handleToggleTripType = (s: TripSegment) => {
    const newType: TripType = s.tripType === 'Груженый' ? 'Порожний' : 'Груженый';
    // Optionally flip ops if switching
    const newStartOp: OperationType = newType === 'Груженый' ? 'Загрузка' : 'Разгрузка';
    const newEndOp: OperationType = newType === 'Груженый' ? 'Разгрузка' : 'Загрузка';
    onUpdateSegment({
      ...s,
      tripType: newType,
      startOp: newStartOp,
      endOp: newEndOp,
    });
  };

  return (
    <div className="bg-slate-800/80 border border-slate-700/80 rounded-2xl shadow-xl overflow-hidden">
      {/* Table Toolbar */}
      <div className="p-4 sm:p-5 border-b border-slate-700/80 flex flex-col md:flex-row md:items-center justify-between gap-3 bg-slate-800/40">
        <div>
          <h3 className="text-base font-bold text-white flex items-center gap-2">
            <FileSpreadsheet className="w-5 h-5 text-emerald-400" />
            Итоговая таблица пробега между точками (З → Р)
          </h3>
          <p className="text-xs text-slate-400 mt-0.5">
            Готова к экспорту в Excel, путевой лист и отчет для логиста
          </p>
        </div>

        {/* Export & Action Buttons */}
        <div className="flex items-center gap-2 flex-wrap">
          <button
            onClick={handleCopyMarkdown}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-all ${
              copiedMd
                ? 'bg-emerald-500 text-slate-950 font-bold'
                : 'bg-slate-700 hover:bg-slate-600 text-slate-200 border border-slate-600'
            }`}
            title="Скопировать чистую таблицу Markdown (как в запросе)"
          >
            {copiedMd ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5 text-amber-400" />}
            <span>{copiedMd ? 'Скопировано в буфер!' : 'Скопировать Markdown'}</span>
          </button>

          <button
            onClick={handleCopyExcel}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-all ${
              copiedExcel
                ? 'bg-emerald-500 text-slate-950 font-bold'
                : 'bg-slate-700 hover:bg-slate-600 text-slate-200 border border-slate-600'
            }`}
            title="Скопировать для вставки в Excel или Google Таблицы (Ctrl+V в ячейку)"
          >
            {copiedExcel ? <Check className="w-3.5 h-3.5" /> : <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-400" />}
            <span>{copiedExcel ? 'Таблица в буфере!' : 'Копировать для Excel'}</span>
          </button>

          <button
            onClick={handleDownloadCsv}
            className="px-3 py-1.5 rounded-lg bg-slate-700 hover:bg-slate-600 text-slate-200 border border-slate-600 text-xs font-semibold flex items-center gap-1.5 transition-colors"
            title="Скачать файл CSV"
          >
            <Download className="w-3.5 h-3.5 text-blue-400" />
            <span>CSV</span>
          </button>

          <button
            onClick={() => window.print()}
            className="px-3 py-1.5 rounded-lg bg-slate-700 hover:bg-slate-600 text-slate-200 border border-slate-600 text-xs font-semibold flex items-center gap-1.5 transition-colors no-print"
            title="Распечатать путевой отчет"
          >
            <Printer className="w-3.5 h-3.5 text-slate-300" />
            <span>Печать</span>
          </button>

          <button
            onClick={onAddSegment}
            className="px-3 py-1.5 rounded-lg bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs flex items-center gap-1.5 transition-all shadow-md shadow-amber-500/10"
            title="Добавить новый участок пути вручную"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Добавить точку</span>
          </button>
        </div>
      </div>

      {/* Main Table Responsive Container */}
      <div className="overflow-x-auto">
        <table className="w-full text-left text-sm border-collapse">
          <thead>
            <tr className="bg-slate-900/80 text-slate-400 text-[11px] uppercase tracking-wider font-semibold border-b border-slate-700/80">
              <th className="py-3 px-3 w-12 text-center">#</th>
              <th className="py-3 px-3 min-w-[90px]">Дата</th>
              <th className="py-3 px-4 min-w-[180px]">Начальная точка (Откуда / Адрес)</th>
              <th className="py-3 px-3 min-w-[110px]">Тип операции</th>
              <th className="py-3 px-4 min-w-[180px]">Конечная точка (Куда / Адрес)</th>
              <th className="py-3 px-3 min-w-[110px]">Тип операции</th>
              <th className="py-3 px-3 min-w-[120px] text-center">Тип рейса</th>
              <th className="py-3 px-4 min-w-[110px] text-right">Расстояние (км)</th>
              <th className="py-3 px-3 w-28 text-center no-print">Действия</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-700/50">
            {segments.length === 0 ? (
              <tr>
                <td colSpan={9} className="py-12 text-center text-slate-400">
                  <Truck className="w-10 h-10 mx-auto text-slate-600 mb-2 stroke-[1.5]" />
                  <p className="text-sm font-medium">Нет добавленных рейсов</p>
                  <p className="text-xs text-slate-500 mt-1">
                    Вставьте путевые заметки в поле выше или нажмите «Добавить точку»
                  </p>
                </td>
              </tr>
            ) : (
              segments.map((seg, idx) => {
                const isLoaded = seg.tripType === 'Груженый';
                const isEditingDistance = editingDistanceId === seg.id;

                return (
                  <tr
                    key={seg.id}
                    className={`transition-colors hover:bg-slate-700/30 ${
                      !isLoaded ? 'bg-amber-500/[0.02]' : ''
                    }`}
                  >
                    {/* Index */}
                    <td className="py-3 px-3 text-center text-xs font-mono text-slate-500">
                      {idx + 1}
                    </td>

                    {/* Date */}
                    <td className="py-3 px-3 text-xs font-mono text-slate-300">
                      {seg.date || <span className="text-slate-600">—</span>}
                    </td>

                    {/* Start Location */}
                    <td className="py-3 px-4 text-xs font-medium text-slate-200">
                      <div className="flex items-center gap-1.5">
                        <span className="w-2 h-2 rounded-full bg-blue-500 flex-shrink-0" />
                        <span className="font-semibold">{seg.startLocation}</span>
                      </div>
                      {seg.notes && (
                        <p className="text-[10px] text-slate-500 truncate max-w-xs mt-0.5">
                          {seg.notes}
                        </p>
                      )}
                    </td>

                    {/* Start Operation */}
                    <td className="py-3 px-3">
                      <span
                        className={`inline-flex items-center px-2 py-0.5 rounded text-[11px] font-semibold border ${
                          seg.startOp === 'Загрузка'
                            ? 'bg-blue-500/10 text-blue-400 border-blue-500/30'
                            : 'bg-purple-500/10 text-purple-400 border-purple-500/30'
                        }`}
                      >
                        {seg.startOp}
                      </span>
                    </td>

                    {/* End Location */}
                    <td className="py-3 px-4 text-xs font-medium text-slate-200">
                      <div className="flex items-center gap-1.5">
                        <span className="w-2 h-2 rounded-full bg-amber-500 flex-shrink-0" />
                        <span className="font-semibold">{seg.endLocation}</span>
                      </div>
                    </td>

                    {/* End Operation */}
                    <td className="py-3 px-3">
                      <span
                        className={`inline-flex items-center px-2 py-0.5 rounded text-[11px] font-semibold border ${
                          seg.endOp === 'Разгрузка'
                            ? 'bg-purple-500/10 text-purple-400 border-purple-500/30'
                            : 'bg-blue-500/10 text-blue-400 border-blue-500/30'
                        }`}
                      >
                        {seg.endOp}
                      </span>
                    </td>

                    {/* Trip Type */}
                    <td className="py-3 px-3 text-center">
                      <button
                        onClick={() => handleToggleTripType(seg)}
                        className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-bold border transition-transform hover:scale-105 cursor-pointer ${
                          isLoaded
                            ? 'bg-emerald-500/15 text-emerald-400 border-emerald-500/30 hover:bg-emerald-500/25'
                            : 'bg-amber-500/15 text-amber-400 border-amber-500/30 hover:bg-amber-500/25'
                        }`}
                        title="Нажмите, чтобы переключить тип рейса (Груженый / Порожний)"
                      >
                        {isLoaded ? (
                          <>
                            <Package className="w-3.5 h-3.5" />
                            <span>Груженый</span>
                          </>
                        ) : (
                          <>
                            <Box className="w-3.5 h-3.5" />
                            <span>Порожний</span>
                          </>
                        )}
                      </button>
                    </td>

                    {/* Distance (km) */}
                    <td className="py-3 px-4 text-right">
                      {isEditingDistance ? (
                        <div className="flex items-center justify-end gap-1">
                          <input
                            type="number"
                            value={tempDistance}
                            onChange={(e) => setTempDistance(e.target.value)}
                            onKeyDown={(e) => {
                              if (e.key === 'Enter') handleSaveDistance(seg);
                              if (e.key === 'Escape') setEditingDistanceId(null);
                            }}
                            autoFocus
                            className="w-20 px-2 py-0.5 text-xs text-right bg-slate-900 border border-amber-500 rounded font-mono font-bold text-white focus:outline-none"
                          />
                          <button
                            onClick={() => handleSaveDistance(seg)}
                            className="p-1 rounded bg-amber-500 text-slate-950 hover:bg-amber-400 text-xs"
                          >
                            <Check className="w-3 h-3" />
                          </button>
                        </div>
                      ) : (
                        <div
                          onClick={() => handleStartEditDistance(seg)}
                          className="font-mono font-bold text-sm text-slate-100 hover:text-amber-400 cursor-pointer inline-flex items-center gap-1 group/km"
                          title="Нажмите, чтобы исправить километраж по одометру"
                        >
                          <span>{seg.distanceKm.toLocaleString('ru-RU')}</span>
                          <span className="text-xs text-slate-400 font-normal">км</span>
                          <Edit2 className="w-3 h-3 opacity-0 group-hover/km:opacity-100 text-slate-400 transition-opacity" />
                        </div>
                      )}
                    </td>

                    {/* Actions */}
                    <td className="py-3 px-3 text-center no-print">
                      <div className="flex items-center justify-center gap-1">
                        <button
                          onClick={() => onMoveSegment(idx, 'up')}
                          disabled={idx === 0}
                          className="p-1 rounded text-slate-500 hover:text-slate-300 disabled:opacity-30 disabled:cursor-not-allowed transition-colors"
                          title="Поднять выше"
                        >
                          <ArrowUp className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => onMoveSegment(idx, 'down')}
                          disabled={idx === segments.length - 1}
                          className="p-1 rounded text-slate-500 hover:text-slate-300 disabled:opacity-30 disabled:cursor-not-allowed transition-colors"
                          title="Опустить ниже"
                        >
                          <ArrowDown className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => onOpenEditModal(seg)}
                          className="p-1 rounded text-slate-400 hover:text-amber-400 transition-colors"
                          title="Редактировать участок"
                        >
                          <Edit2 className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => onDeleteSegment(seg.id)}
                          className="p-1 rounded text-slate-400 hover:text-red-400 transition-colors"
                          title="Удалить"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })
            )}
          </tbody>

          {/* Table Footer with Summary */}
          {segments.length > 0 && (
            <tfoot>
              <tr className="bg-slate-900/90 font-bold border-t-2 border-slate-700 text-slate-100">
                <td colSpan={7} className="py-3.5 px-4 text-sm uppercase tracking-wide">
                  <div className="flex items-center justify-between">
                    <span className="font-extrabold text-white">ИТОГО ЗА МЕСЯЦ:</span>
                    <div className="flex items-center gap-4 text-xs font-normal text-slate-300 hidden sm:flex">
                      <span>
                        Груженый: <strong className="text-emerald-400 font-mono">{loadedKm} км</strong>
                      </span>
                      <span>
                        Порожний: <strong className="text-amber-400 font-mono">{emptyKm} км</strong>
                      </span>
                    </div>
                  </div>
                </td>
                <td className="py-3.5 px-4 text-right font-mono text-base font-extrabold text-amber-400">
                  {totalKm.toLocaleString('ru-RU')} км
                </td>
                <td className="no-print"></td>
              </tr>
            </tfoot>
          )}
        </table>
      </div>

      {/* Duplicated Summary Block as strictly requested in prompt */}
      {segments.length > 0 && (
        <div className="p-4 sm:p-5 bg-slate-900/95 border-t border-slate-700/80">
          <h4 className="text-xs uppercase font-extrabold tracking-wider text-slate-400 mb-2">
            ИТОГОВЫЕ ЦИФРЫ (для копирования в отчет):
          </h4>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-sm">
            <div className="p-3 rounded-xl bg-slate-800/80 border border-slate-700">
              <span className="text-slate-400 text-xs block">Общий пробег за месяц:</span>
              <span className="text-lg font-black text-white font-mono">
                {totalKm.toLocaleString('ru-RU')} км
              </span>
            </div>
            <div className="p-3 rounded-xl bg-emerald-950/20 border border-emerald-500/30">
              <span className="text-emerald-400/80 text-xs block">Пробег под грузом:</span>
              <span className="text-lg font-black text-emerald-400 font-mono">
                {loadedKm.toLocaleString('ru-RU')} км{' '}
                <span className="text-xs font-bold">
                  ({totalKm > 0 ? ((loadedKm / totalKm) * 100).toFixed(1) : 0}%)
                </span>
              </span>
            </div>
            <div className="p-3 rounded-xl bg-amber-950/20 border border-amber-500/30">
              <span className="text-amber-400/80 text-xs block">Порожний (холостой) пробег:</span>
              <span className="text-lg font-black text-amber-400 font-mono">
                {emptyKm.toLocaleString('ru-RU')} км{' '}
                <span className="text-xs font-bold">
                  ({totalKm > 0 ? ((emptyKm / totalKm) * 100).toFixed(1) : 0}%)
                </span>
              </span>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
