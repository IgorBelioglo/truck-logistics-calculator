import React, { useState } from 'react';
import { CalculationSettings } from '../types/logistics';
import { X, Check, DollarSign, Fuel, RotateCcw } from 'lucide-react';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  settings: CalculationSettings;
  onSave: (newSettings: CalculationSettings) => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  isOpen,
  onClose,
  settings,
  onSave,
}) => {
  const [form, setForm] = useState<CalculationSettings>({ ...settings });

  if (!isOpen) return null;

  const handleResetDefaults = () => {
    setForm({
      loadedRatePerKm: 85,
      emptyRatePerKm: 55,
      fuelConsumptionPer100Km: 32,
      fuelPricePerLiter: 68,
      currency: '₽',
    });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave(form);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-fadeIn">
      <div className="bg-slate-900 border border-slate-700 rounded-2xl w-full max-w-md shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-slate-800 flex items-center justify-between">
          <h3 className="text-base font-bold text-white flex items-center gap-2">
            <DollarSign className="w-5 h-5 text-amber-500" />
            Тарифы водителя и расчет топлива
          </h3>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-4 sm:p-6 space-y-4 text-sm">
          {/* Rates */}
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1">
              Ставка за груженый километр
            </label>
            <div className="relative">
              <input
                type="number"
                min="0"
                step="0.5"
                value={form.loadedRatePerKm}
                onChange={(e) =>
                  setForm({ ...form, loadedRatePerKm: parseFloat(e.target.value) || 0 })
                }
                className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-white font-mono font-bold focus:outline-none focus:ring-2 focus:ring-amber-500"
              />
              <span className="absolute right-3 top-2.5 text-xs text-slate-400 font-semibold">
                {form.currency}/км
              </span>
            </div>
            <p className="text-[11px] text-slate-500 mt-1">Оплата за рейс под грузом (З → Р)</p>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1">
              Ставка за порожний (холостой) километр
            </label>
            <div className="relative">
              <input
                type="number"
                min="0"
                step="0.5"
                value={form.emptyRatePerKm}
                onChange={(e) =>
                  setForm({ ...form, emptyRatePerKm: parseFloat(e.target.value) || 0 })
                }
                className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-white font-mono font-bold focus:outline-none focus:ring-2 focus:ring-amber-500"
              />
              <span className="absolute right-3 top-2.5 text-xs text-slate-400 font-semibold">
                {form.currency}/км
              </span>
            </div>
            <p className="text-[11px] text-slate-500 mt-1">
              Компенсация холостого перегона или подачи под загрузку (Р → З)
            </p>
          </div>

          {/* Fuel */}
          <div className="pt-2 border-t border-slate-800">
            <label className="block text-xs font-semibold text-slate-300 mb-1">
              Расход топлива тягача (л / 100 км)
            </label>
            <div className="relative">
              <input
                type="number"
                min="10"
                max="60"
                step="0.5"
                value={form.fuelConsumptionPer100Km}
                onChange={(e) =>
                  setForm({
                    ...form,
                    fuelConsumptionPer100Km: parseFloat(e.target.value) || 0,
                  })
                }
                className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-white font-mono font-bold focus:outline-none focus:ring-2 focus:ring-amber-500"
              />
              <span className="absolute right-3 top-2.5 text-xs text-slate-400 font-semibold">
                л/100км
              </span>
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1">
              Стоимость дизельного топлива (ДТ)
            </label>
            <div className="relative">
              <input
                type="number"
                min="0"
                step="0.1"
                value={form.fuelPricePerLiter}
                onChange={(e) =>
                  setForm({ ...form, fuelPricePerLiter: parseFloat(e.target.value) || 0 })
                }
                className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-white font-mono font-bold focus:outline-none focus:ring-2 focus:ring-amber-500"
              />
              <span className="absolute right-3 top-2.5 text-xs text-slate-400 font-semibold">
                {form.currency}/литр
              </span>
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1">
              Валюта расчета
            </label>
            <select
              value={form.currency}
              onChange={(e) => setForm({ ...form, currency: e.target.value })}
              className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-white font-bold focus:outline-none focus:ring-2 focus:ring-amber-500"
            >
              <option value="₽">Рубли (₽)</option>
              <option value="₸">Тенге (₸)</option>
              <option value="Br">Бел. рубли (Br)</option>
              <option value="$">USD ($)</option>
              <option value="€">EUR (€)</option>
            </select>
          </div>

          {/* Actions */}
          <div className="pt-3 border-t border-slate-800 flex items-center justify-between">
            <button
              type="button"
              onClick={handleResetDefaults}
              className="text-xs text-slate-400 hover:text-slate-200 flex items-center gap-1"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Сбросить</span>
            </button>
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={onClose}
                className="px-3.5 py-2 rounded-xl text-slate-300 hover:bg-slate-800 text-xs font-medium"
              >
                Отмена
              </button>
              <button
                type="submit"
                className="px-4 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs shadow-md shadow-amber-500/20 flex items-center gap-1.5"
              >
                <Check className="w-3.5 h-3.5" />
                <span>Применить</span>
              </button>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
};
