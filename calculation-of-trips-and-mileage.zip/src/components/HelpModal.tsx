import React from 'react';
import { X, BookOpen, CheckCircle2, Truck, ArrowRight, FileSpreadsheet, MapPin } from 'lucide-react';

interface HelpModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const HelpModal: React.FC<HelpModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-fadeIn">
      <div className="bg-slate-900 border border-slate-700 rounded-2xl w-full max-w-xl shadow-2xl overflow-hidden max-h-[90vh] flex flex-col">
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-slate-800 flex items-center justify-between">
          <h3 className="text-base font-bold text-white flex items-center gap-2">
            <BookOpen className="w-5 h-5 text-amber-500" />
            Инструкция логиста: специфика расчетов
          </h3>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-4 sm:p-6 overflow-y-auto space-y-4 text-xs sm:text-sm text-slate-300 leading-relaxed">
          {/* Rule 1 */}
          <div className="p-3.5 rounded-xl bg-slate-800/80 border border-slate-700 space-y-2">
            <h4 className="font-bold text-amber-400 flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-400" />
              1. Последовательность точек и тип рейса
            </h4>
            <p>
              • <strong>Груженый рейс (З → Р):</strong> Перемещение груза от точки Загрузки к точке Разгрузки. Оплачивается по полной ставке.
            </p>
            <p>
              • <strong>Порожний пробег (Р → З):</strong> Холостой перегон пустой фуры между точкой предыдущей выгрузки и следующей погрузкой. Учитывается отдельно для прозрачной бухгалтерии и компенсации затрат на солярку.
            </p>
          </div>

          {/* Rule 2 */}
          <div className="p-3.5 rounded-xl bg-slate-800/80 border border-slate-700 space-y-2">
            <h4 className="font-bold text-amber-400 flex items-center gap-2">
              <MapPin className="w-4 h-4 text-blue-400" />
              2. Распознавание городов и сокращений
            </h4>
            <p>
              Система автоматически нормализует сленг и сокращения водителей:
            </p>
            <div className="grid grid-cols-2 gap-1.5 text-[11px] font-mono bg-slate-900/60 p-2.5 rounded-lg border border-slate-700/60">
              <div>Мск / Селятино → Москва</div>
              <div>Питер / Шушары → СПб</div>
              <div>НН / Нижний → Н. Новгород</div>
              <div>Челны → Наб. Челны</div>
              <div>Екб / Ебург → Екатеринбург</div>
              <div>РнД / Ростов → Ростов-на-Дону</div>
              <div>Врн → Воронеж</div>
              <div>Крд → Краснодар</div>
            </div>
          </div>

          {/* Rule 3 */}
          <div className="p-3.5 rounded-xl bg-slate-800/80 border border-slate-700 space-y-2">
            <h4 className="font-bold text-amber-400 flex items-center gap-2">
              <FileSpreadsheet className="w-4 h-4 text-emerald-400" />
              3. Экспорт в отчет и Excel
            </h4>
            <p>
              • <strong>Скопировать Markdown:</strong> формирует точную текстовую Markdown-таблицу со столбцами «Дата», «Откуда», «Тип операции», «Куда», «Тип операции», «Тип рейса», «Расстояние (км)» и сводкой ИТОГО.
            </p>
            <p>
              • <strong>Копировать для Excel:</strong> помещает данные в буфер обмена в формате TSV — просто откройте Microsoft Excel или Google Sheets и нажмите <code>Ctrl+V</code>.
            </p>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-slate-800 flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-medium text-xs transition-colors"
          >
            Понятно, закрыть
          </button>
        </div>
      </div>
    </div>
  );
};
