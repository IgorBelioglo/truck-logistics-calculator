import React, { useEffect, useRef, useState } from 'react';
import L from 'leaflet';
import { TripSegment } from '../types/logistics';
import { findCity } from '../utils/geoUtils';
import { MapPin, Navigation, Eye, EyeOff, Layers } from 'lucide-react';

interface RouteMapProps {
  segments: TripSegment[];
}

export const RouteMap: React.FC<RouteMapProps> = ({ segments }) => {
  const mapContainerRef = useRef<HTMLDivElement>(null);
  const mapInstanceRef = useRef<L.Map | null>(null);
  const layerGroupRef = useRef<L.LayerGroup | null>(null);
  const [isExpanded, setIsExpanded] = useState(true);

  useEffect(() => {
    if (!mapContainerRef.current) return;

    if (!mapInstanceRef.current) {
      // Default center around central Russia / Moscow - Volga region
      const map = L.map(mapContainerRef.current, {
        center: [55.7558, 37.6173],
        zoom: 5,
        scrollWheelZoom: true,
      });

      // CartoDB Dark Matter tiles (great for dark theme)
      L.tileLayer('https://{s}.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}{r}.png', {
        attribution: '&copy; OpenStreetMap contributors &copy; CARTO',
        subdomains: 'abcd',
        maxZoom: 19,
      }).addTo(map);

      const layerGroup = L.layerGroup().addTo(map);
      layerGroupRef.current = layerGroup;
      mapInstanceRef.current = map;
    }

    const map = mapInstanceRef.current;
    const layerGroup = layerGroupRef.current;
    if (!map || !layerGroup) return;

    layerGroup.clearLayers();

    const bounds = L.latLngBounds([]);
    let hasCoords = false;

    // Custom marker icon helper
    const createCustomIcon = (number: number, isLoaded: boolean, op: string) => {
      const bgColor = isLoaded ? '#10b981' : '#f59e0b';
      return L.divIcon({
        className: 'custom-map-pin',
        html: `<div style="
          background-color: ${bgColor};
          color: #020617;
          width: 24px;
          height: 24px;
          border-radius: 50%;
          display: flex;
          align-items: center;
          justify-content: center;
          font-weight: 800;
          font-size: 11px;
          border: 2px solid #ffffff;
          box-shadow: 0 2px 6px rgba(0,0,0,0.4);
        ">${number}</div>`,
        iconSize: [24, 24],
        iconAnchor: [12, 12],
      });
    };

    segments.forEach((seg, idx) => {
      // Resolve coordinates
      let startCoords = seg.startCoords;
      let endCoords = seg.endCoords;

      if (!startCoords) {
        const city = findCity(seg.startLocation);
        if (city) startCoords = [city.lat, city.lng];
      }
      if (!endCoords) {
        const city = findCity(seg.endLocation);
        if (city) endCoords = [city.lat, city.lng];
      }

      const isLoaded = seg.tripType === 'Груженый';
      const color = isLoaded ? '#10b981' : '#f59e0b';
      const dashArray = isLoaded ? undefined : '6, 8';

      if (startCoords) {
        const startLatLng = L.latLng(startCoords[0], startCoords[1]);
        bounds.extend(startLatLng);
        hasCoords = true;

        const startMarker = L.marker(startLatLng, {
          icon: createCustomIcon(idx + 1, isLoaded, seg.startOp),
        });
        startMarker.bindPopup(`
          <div style="font-family: sans-serif; font-size: 12px; color: #0f172a;">
            <strong>Плечо #${idx + 1}: ${seg.startLocation}</strong><br/>
            Операция: <b>${seg.startOp}</b><br/>
            ${seg.date ? `Дата: ${seg.date}<br/>` : ''}
            Куда: ${seg.endLocation}<br/>
            Тип: <b>${seg.tripType}</b> (${seg.distanceKm} км)
          </div>
        `);
        layerGroup.addLayer(startMarker);
      }

      if (endCoords) {
        const endLatLng = L.latLng(endCoords[0], endCoords[1]);
        bounds.extend(endLatLng);
        hasCoords = true;

        const endMarker = L.marker(endLatLng, {
          icon: createCustomIcon(idx + 1, isLoaded, seg.endOp),
        });
        endMarker.bindPopup(`
          <div style="font-family: sans-serif; font-size: 12px; color: #0f172a;">
            <strong>Точка прибытия: ${seg.endLocation}</strong><br/>
            Операция: <b>${seg.endOp}</b><br/>
            Откуда: ${seg.startLocation}<br/>
            Расстояние: <b>${seg.distanceKm} км</b>
          </div>
        `);
        layerGroup.addLayer(endMarker);
      }

      // Draw route line between start and end
      if (startCoords && endCoords) {
        const polyline = L.polyline(
          [
            [startCoords[0], startCoords[1]],
            [endCoords[0], endCoords[1]],
          ],
          {
            color,
            weight: isLoaded ? 4 : 3,
            opacity: 0.85,
            dashArray,
          }
        );

        polyline.bindPopup(`
          <div style="font-family: sans-serif; font-size: 12px; color: #0f172a;">
            <strong>${seg.startLocation} → ${seg.endLocation}</strong><br/>
            Рейс: <b style="color: ${color};">${seg.tripType}</b><br/>
            Расстояние: <b>${seg.distanceKm} км</b>
          </div>
        `);

        layerGroup.addLayer(polyline);
      }
    });

    if (hasCoords && bounds.isValid()) {
      map.fitBounds(bounds, { padding: [40, 40], maxZoom: 8 });
    }

    setTimeout(() => {
      map.invalidateSize();
    }, 200);
  }, [segments, isExpanded]);

  return (
    <div className="bg-slate-800/80 border border-slate-700/80 rounded-2xl shadow-xl overflow-hidden">
      {/* Map Header */}
      <div className="p-4 sm:p-5 border-b border-slate-700/80 flex items-center justify-between bg-slate-800/40">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg bg-blue-500/10 text-blue-400 flex items-center justify-center border border-blue-500/20">
            <Navigation className="w-4 h-4" />
          </div>
          <div>
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              Интерактивная карта рейсов
            </h3>
            <p className="text-xs text-slate-400">
              Наглядная схема движения: сплошные линии — груз, пунктирные — холостой пробег
            </p>
          </div>
        </div>

        {/* Legend & Toggle */}
        <div className="flex items-center gap-3">
          <div className="hidden sm:flex items-center gap-3 text-xs bg-slate-900/80 px-3 py-1.5 rounded-lg border border-slate-700">
            <div className="flex items-center gap-1.5">
              <span className="w-3 h-1 bg-emerald-500 rounded" />
              <span className="text-emerald-400 font-medium">Груженый</span>
            </div>
            <div className="flex items-center gap-1.5">
              <span className="w-3 h-0.5 border-t-2 border-dashed border-amber-500" />
              <span className="text-amber-400 font-medium">Порожний (Р → З)</span>
            </div>
          </div>

          <button
            onClick={() => setIsExpanded(!isExpanded)}
            className="p-1.5 rounded-lg bg-slate-700 hover:bg-slate-600 text-slate-300 hover:text-white transition-colors"
            title={isExpanded ? 'Свернуть карту' : 'Развернуть карту'}
          >
            {isExpanded ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
          </button>
        </div>
      </div>

      {/* Map Canvas */}
      {isExpanded && (
        <div className="relative w-full h-[380px] sm:h-[440px] bg-slate-950">
          <div ref={mapContainerRef} className="w-full h-full" />
          {segments.length === 0 && (
            <div className="absolute inset-0 bg-slate-900/80 backdrop-blur-sm flex items-center justify-center pointer-events-none z-[1000]">
              <div className="text-center text-slate-400 p-4">
                <MapPin className="w-8 h-8 mx-auto text-slate-500 mb-2" />
                <p className="text-sm font-medium">Карта отобразится после добавления точек рейса</p>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
