import React, { useState, useEffect } from 'react';
import { OperationType, TripSegment, TripType } from '../types/logistics';
import { calculateRoadDistance } from '../utils/geoUtils';
import { X, Check, Calculator, MapPin, Calendar, Package, Box } from 'lucide-react';

interface EditSegmentModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (segment: TripSegment) => void;
  initialSegment: TripSegment | null;
}

export const EditSegmentModal: React.FC<EditSegmentModalProps> = ({
  isOpen,
  onClose,
  onSave,
  initialSegment,
}) => {
  const [date, setDate] = useState('');
  const [startLocation, setStartLocation] = useState('');
  const [startOp, setStartOp] = useState<OperationType>('Загрузка');
  const [endLocation, setEndLocation] = useState('');
  const [endOp, setEndOp] = useState<OperationType>('Разгрузка');
  const [tripType, setTripType] = useState<TripType>('Груженый');
  const [distanceKm, setDistanceKm] = useState<number>(0);
  const [notes, setNotes] = useState('');

  useEffect(() => {
    if (initialSegment) {
      setDate(initialSegment.date || '');
      setStartLocation(initialSegment.startLocation);
      setStartOp(initialSegment.startOp);
      setEndLocation(initialSegment.endLocation);
      setEndOp(initialSegment.endOp);
      setTripType(initialSegment.tripType);
      setDistanceKm(initialSegment.distanceKm);
      setNotes(initialSegment.notes || '');
    } else {
      // New segment default
      setDate(new Date().toISOString().slice(5, 10).replace('-', '.'));
      setStartLocation('');
      setStartOp('Загрузка');
      setEndLocation('');
      setEndOp('Разгрузка');
      setTripType('Груженый');
      setDistanceKm(0);
      setNotes('');
    }
  }, [initialSegment, isOpen]);

  if (!isOpen) return null;

  // Auto calculate distance on button click
  const handleRecalculateDistance = () => {
    if (!startLocation || !endLocation) return;
    const calc = calculateRoadDistance(startLocation, endLocation);
    setDistanceKm(calc.distanceKm);
    if (calc.normalizedStart && calc.normalizedStart !== startLocation) {
      setStartLocation(calc.normalizedStart);
    }
    if (calc.normalizedEnd && calc.normalizedEnd !== endLocation) {
      setEndLocation(calc.normalizedEnd);
    }
  };

  const handleTripTypeChange = (type: TripType) => {
    setTripType(type);
    if (type === 'Порожний') {
      setStartOp('Разгрузка');
      setEndOp('Загрузка');
    } else {
      setStartOp('Загрузка');
      setEndOp('Разгрузка');
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!startLocation.trim() || !endLocation.trim()) return;

    const calc = calculateRoadDistance(startLocation, endLocation);

    const segment: TripSegment = {
      id: initialSegment ? initialSegment.id : `seg-${Date.now()}-${Math.random().toString(36).substr(2, 5)}`,
      date: date.trim(),
      startLocation: startLocation.trim(),
      startOp,
      endLocation: endLocation.trim(),
      endOp,
      tripType,
      distanceKm: distanceKm > 0 ? distanceKm : calc.distanceKm,
      notes: notes.trim(),
      startCoords: calc.startCoords,
      endCoords: calc.endCoords,
    };

    onSave(segment);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-fadeIn">
      <div className="bg-slate-900 border border-slate-700 rounded-2xl w-full max-w-lg shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-slate-800 flex items-center justify-between">
          <h3 className="text-base font-bold text-white flex items-center gap-2">
            <MapPin className="w-5 h-5 text-amber-500" />
            {initialSegment ? 'Редактировать участок рейса' : 'Добавить новый участок рейса'}
          </h3>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-4 sm:p-6 space-y-4">
          {/* Date & Trip Type */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                Дата рейса
              </label>
              <div className="relative">
                <input
                  type="text"
                  value={date}
                  onChange={(e) => setDate(e.target.value)}
                  placeholder="Например: 02.05 или 02.05.2024"
                  className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-sm text-slate-100 placeholder:text-slate-500 focus:outline-none focus:ring-2 focus:ring-amber-500"
                />
                <Calendar className="w-4 h-4 text-slate-500 absolute right-3 top-2.5 pointer-events-none" />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                Тип рейса
              </label>
              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() => handleTripTypeChange('Груженый')}
                  className={`py-2 px-2 rounded-xl text-xs font-bold border transition-all flex items-center justify-center gap-1 ${
                    tripType === 'Груженый'
                      ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40 shadow-sm'
                      : 'bg-slate-800 text-slate-400 border-slate-700 hover:text-slate-200'
                  }`}
                >
                  <Package className="w-3.5 h-3.5" />
                  <span>Груженый</span>
                </button>
                <button
                  type="button"
                  onClick={() => handleTripTypeChange('Порожний')}
                  className={`py-2 px-2 rounded-xl text-xs font-bold border transition-all flex items-center justify-center gap-1 ${
                    tripType === 'Порожний'
                      ? 'bg-amber-500/20 text-amber-300 border-amber-500/40 shadow-sm'
                      : 'bg-slate-800 text-slate-400 border-slate-700 hover:text-slate-200'
                  }`}
                >
                  <Box className="w-3.5 h-3.5" />
                  <span>Порожний</span>
                </button>
              </div>
            </div>
          </div>

          {/* Start Point & Op */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div className="sm:col-span-2">
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                Начальная точка (Откуда / Адрес)
              </label>
              <input
                type="text"
                required
                value={startLocation}
                onChange={(e) => setStartLocation(e.target.value)}
                placeholder="Москва, склад Селятино"
                className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-sm text-slate-100 placeholder:text-slate-500 focus:outline-none focus:ring-2 focus:ring-amber-500"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                Операция
              </label>
              <select
                value={startOp}
                onChange={(e) => setStartOp(e.target.value as OperationType)}
                className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-sm text-slate-100 focus:outline-none focus:ring-2 focus:ring-amber-500"
              >
                <option value="Загрузка">Загрузка</option>
                <option value="Разгрузка">Разгрузка</option>
              </select>
            </div>
          </div>

          {/* End Point & Op */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div className="sm:col-span-2">
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                Конечная точка (Куда / Адрес)
              </label>
              <input
                type="text"
                required
                value={endLocation}
                onChange={(e) => setEndLocation(e.target.value)}
                placeholder="Тверь, РЦ Магнит"
                className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-sm text-slate-100 placeholder:text-slate-500 focus:outline-none focus:ring-2 focus:ring-amber-500"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                Операция
              </label>
              <select
                value={endOp}
                onChange={(e) => setEndOp(e.target.value as OperationType)}
                className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-sm text-slate-100 focus:outline-none focus:ring-2 focus:ring-amber-500"
              >
                <option value="Разгрузка">Разгрузка</option>
                <option value="Загрузка">Загрузка</option>
              </select>
            </div>
          </div>

          {/* Distance with Auto-Calculate Button */}
          <div>
            <div className="flex items-center justify-between mb-1">
              <label className="text-xs font-semibold text-slate-300">
                Расстояние по трассе (км)
              </label>
              <button
                type="button"
                onClick={handleRecalculateDistance}
                className="text-xs text-amber-400 hover:text-amber-300 flex items-center gap-1 font-medium"
              >
                <Calculator className="w-3.5 h-3.5" />
                <span>Рассчитать автоматически</span>
              </button>
            </div>
            <div className="relative">
              <input
                type="number"
                min="0"
                value={distanceKm || ''}
                onChange={(e) => setDistanceKm(parseInt(e.target.value, 10) || 0)}
                placeholder="Километраж"
                className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-sm font-mono font-bold text-white focus:outline-none focus:ring-2 focus:ring-amber-500"
              />
              <span className="absolute right-3 top-2.5 text-xs text-slate-400 font-semibold">
                км
              </span>
            </div>
          </div>

          {/* Notes */}
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1">
              Примечание (характер груза, накладная, особенности)
            </label>
            <input
              type="text"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="Например: стройматериалы 20т, тент, ночная выгрузка"
              className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-sm text-slate-100 placeholder:text-slate-500 focus:outline-none focus:ring-2 focus:ring-amber-500"
            />
          </div>

          {/* Submit Actions */}
          <div className="pt-3 border-t border-slate-800 flex items-center justify-end gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-xl text-slate-300 hover:bg-slate-800 text-sm font-medium transition-colors"
            >
              Отмена
            </button>
            <button
              type="submit"
              className="px-5 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-sm shadow-md shadow-amber-500/20 transition-all flex items-center gap-1.5"
            >
              <Check className="w-4 h-4" />
              <span>Сохранить</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
