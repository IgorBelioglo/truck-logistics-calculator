import React from 'react';
import { CalculationSettings, TripSegment } from '../types/logistics';
import { Route, Fuel, TrendingUp, AlertTriangle, Wallet, ArrowRight } from 'lucide-react';

interface SummaryCardsProps {
  segments: TripSegment[];
  settings: CalculationSettings;
}

export const SummaryCards: React.FC<SummaryCardsProps> = ({ segments, settings }) => {
  const loadedKm = segments
    .filter((s) => s.tripType === 'Груженый')
    .reduce((acc, curr) => acc + (curr.distanceKm || 0), 0);

  const emptyKm = segments
    .filter((s) => s.tripType === 'Порожний')
    .reduce((acc, curr) => acc + (curr.distanceKm || 0), 0);

  const totalKm = loadedKm + emptyKm;
  const loadedPercent = totalKm > 0 ? Math.round((loadedKm / totalKm) * 100) : 0;
  const emptyPercent = totalKm > 0 ? Math.round((emptyKm / totalKm) * 100) : 0;

  // Fuel calculation
  const totalFuelLiters = Math.round((totalKm * settings.fuelConsumptionPer100Km) / 100);
  const totalFuelCost = Math.round(totalFuelLiters * settings.fuelPricePerLiter);

  // Driver pay calculation
  const driverPayLoaded = loadedKm * settings.loadedRatePerKm;
  const driverPayEmpty = emptyKm * settings.emptyRatePerKm;
  const totalDriverPay = driverPayLoaded + driverPayEmpty;

  return (
    <div className="space-y-4">
      {/* 3 Core Metric Cards as requested by user prompt */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        {/* Total Mileage */}
        <div className="bg-slate-800/80 border border-slate-700/80 rounded-2xl p-5 shadow-lg relative overflow-hidden group hover:border-slate-600 transition-all">
          <div className="flex items-center justify-between">
            <span className="text-xs uppercase font-bold tracking-wider text-slate-400">
              Общий пробег за месяц
            </span>
            <div className="w-9 h-9 rounded-xl bg-blue-500/10 text-blue-400 flex items-center justify-center border border-blue-500/20">
              <Route className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-3xl sm:text-4xl font-black tracking-tight text-white font-mono">
              {totalKm.toLocaleString('ru-RU')}
            </span>
            <span className="text-sm font-semibold text-slate-400">км</span>
          </div>
          <p className="mt-2 text-xs text-slate-400">
            Всего участков: <span className="text-slate-200 font-semibold">{segments.length}</span> плеч(а)
          </p>
          <div className="absolute -right-6 -bottom-6 w-24 h-24 bg-blue-500/5 rounded-full blur-xl pointer-events-none group-hover:bg-blue-500/10 transition-colors" />
        </div>

        {/* Loaded Mileage */}
        <div className="bg-slate-800/80 border border-emerald-500/30 rounded-2xl p-5 shadow-lg relative overflow-hidden group hover:border-emerald-500/50 transition-all bg-gradient-to-br from-slate-800/90 to-emerald-950/20">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-1.5">
              <span className="text-xs uppercase font-bold tracking-wider text-emerald-400">
                Пробег под грузом
              </span>
              <span className="px-1.5 py-0.5 rounded text-[10px] font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                {loadedPercent}%
              </span>
            </div>
            <div className="w-9 h-9 rounded-xl bg-emerald-500/10 text-emerald-400 flex items-center justify-center border border-emerald-500/20">
              <TrendingUp className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-3xl sm:text-4xl font-black tracking-tight text-emerald-400 font-mono">
              {loadedKm.toLocaleString('ru-RU')}
            </span>
            <span className="text-sm font-semibold text-emerald-300/80">км</span>
          </div>
          <div className="mt-2 w-full bg-slate-700/60 rounded-full h-1.5 overflow-hidden">
            <div
              className="bg-emerald-500 h-full rounded-full transition-all duration-500"
              style={{ width: `${loadedPercent}%` }}
            />
          </div>
          <p className="mt-2 text-xs text-emerald-400/80">
            Оплачиваемый рабочий километраж (З → Р)
          </p>
        </div>

        {/* Empty Deadhead Mileage */}
        <div className="bg-slate-800/80 border border-amber-500/30 rounded-2xl p-5 shadow-lg relative overflow-hidden group hover:border-amber-500/50 transition-all bg-gradient-to-br from-slate-800/90 to-amber-950/20">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-1.5">
              <span className="text-xs uppercase font-bold tracking-wider text-amber-400">
                Порожний пробег
              </span>
              <span className="px-1.5 py-0.5 rounded text-[10px] font-bold bg-amber-500/20 text-amber-300 border border-amber-500/30">
                {emptyPercent}%
              </span>
            </div>
            <div className="w-9 h-9 rounded-xl bg-amber-500/10 text-amber-400 flex items-center justify-center border border-amber-500/20">
              <AlertTriangle className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-3xl sm:text-4xl font-black tracking-tight text-amber-400 font-mono">
              {emptyKm.toLocaleString('ru-RU')}
            </span>
            <span className="text-sm font-semibold text-amber-300/80">км</span>
          </div>
          <div className="mt-2 w-full bg-slate-700/60 rounded-full h-1.5 overflow-hidden">
            <div
              className="bg-amber-500 h-full rounded-full transition-all duration-500"
              style={{ width: `${emptyPercent}%` }}
            />
          </div>
          <p className="mt-2 text-xs text-amber-400/80">
            Холостые перегоны и подача под загрузку (Р → З)
          </p>
        </div>
      </div>

      {/* Accounting / Financial Bar */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-4 flex flex-wrap items-center justify-between gap-4 text-xs">
        <div className="flex items-center gap-6 flex-wrap">
          {/* Driver Earnings */}
          <div className="flex items-center gap-2">
            <div className="p-1.5 rounded-lg bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
              <Wallet className="w-4 h-4" />
            </div>
            <div>
              <span className="text-slate-400">Расчетная выплата водителю:</span>{' '}
              <span className="font-bold text-slate-100 font-mono text-sm">
                {totalDriverPay.toLocaleString('ru-RU')} {settings.currency}
              </span>{' '}
              <span className="text-[11px] text-slate-500">
                (груз: {settings.loadedRatePerKm} {settings.currency}/км, пор: {settings.emptyRatePerKm} {settings.currency}/км)
              </span>
            </div>
          </div>

          {/* Fuel Consumption */}
          <div className="flex items-center gap-2">
            <div className="p-1.5 rounded-lg bg-amber-500/10 text-amber-400 border border-amber-500/20">
              <Fuel className="w-4 h-4" />
            </div>
            <div>
              <span className="text-slate-400">Топливо (~{settings.fuelConsumptionPer100Km} л/100км):</span>{' '}
              <span className="font-bold text-slate-100 font-mono text-sm">
                {totalFuelLiters.toLocaleString('ru-RU')} л
              </span>{' '}
              <span className="text-slate-400">
                (≈ {totalFuelCost.toLocaleString('ru-RU')} {settings.currency})
              </span>
            </div>
          </div>
        </div>

        {/* Utilization Ratio */}
        <div className="flex items-center gap-2 text-slate-400">
          <span>КИП (Коэфф. использования):</span>
          <span className={`font-mono font-bold px-2 py-0.5 rounded text-xs ${
            loadedPercent >= 75
              ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
              : 'bg-amber-500/10 text-amber-400 border border-amber-500/20'
          }`}>
            {(totalKm > 0 ? loadedKm / totalKm : 0).toFixed(2)}
          </span>
        </div>
      </div>
    </div>
  );
};
