import React, { useState } from 'react';
import { SAMPLE_DATASETS } from '../utils/textParser';
import { Sparkles, Play, Trash2, BookOpen, AlertCircle, FileText } from 'lucide-react';

interface RawInputSectionProps {
  onProcess: (text: string) => Promise<void>;
  isLoading: boolean;
  rawText: string;
  setRawText: (text: string) => void;
}

export const RawInputSection: React.FC<RawInputSectionProps> = ({
  onProcess,
  isLoading,
  rawText,
  setRawText,
}) => {
  const [selectedSample, setSelectedSample] = useState<string | null>(null);

  const handleSelectSample = (sampleId: string) => {
    const found = SAMPLE_DATASETS.find((s) => s.id === sampleId);
    if (found) {
      setRawText(found.rawText);
      setSelectedSample(sampleId);
    }
  };

  const handleClear = () => {
    setRawText('');
    setSelectedSample(null);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!rawText.trim() || isLoading) return;
    onProcess(rawText);
  };

  return (
    <div className="bg-slate-800/80 border border-slate-700/80 rounded-2xl p-5 shadow-xl">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-4">
        <div>
          <h2 className="text-base font-bold text-white flex items-center gap-2">
            <FileText className="w-5 h-5 text-amber-500" />
            Ввод сырых путевых записей за месяц
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            Вставь заметки из Telegram, сообщения диспетчера, путевые листы или надиктованный текст
          </p>
        </div>

        {/* Quick Sample Selector */}
        <div className="flex items-center gap-2 flex-wrap">
          <span className="text-[11px] font-medium text-slate-400">Примеры:</span>
          {SAMPLE_DATASETS.map((sample) => (
            <button
              key={sample.id}
              type="button"
              onClick={() => handleSelectSample(sample.id)}
              className={`px-2.5 py-1 rounded-lg text-xs font-medium transition-all ${
                selectedSample === sample.id
                  ? 'bg-amber-500 text-slate-950 font-bold shadow-md shadow-amber-500/20'
                  : 'bg-slate-700/60 hover:bg-slate-700 text-slate-300 hover:text-white border border-slate-600/40'
              }`}
            >
              {sample.badge}
            </button>
          ))}
        </div>
      </div>

      <form onSubmit={handleSubmit} className="space-y-3">
        <div className="relative">
          <textarea
            value={rawText}
            onChange={(e) => {
              setRawText(e.target.value);
              setSelectedSample(null);
            }}
            placeholder={`Вставь сюда список адресов или записи водителя. Например:
02.05 Москва (Загрузка) — Тверь (Разгрузка)
03.05 Тверь (Р) — Клин (З) холостой ход
04.05 Клин (З) — Казань (Р)
или просто текст: "выгрузился в Питере, поехал пустой в Новгород загрузился до Нижнего..."`}
            rows={6}
            className="w-full bg-slate-900/90 border border-slate-700 rounded-xl p-3.5 text-sm text-slate-100 placeholder:text-slate-500 focus:outline-none focus:ring-2 focus:ring-amber-500/50 focus:border-amber-500 font-mono resize-y leading-relaxed transition-all"
          />

          {rawText.length > 0 && (
            <button
              type="button"
              onClick={handleClear}
              className="absolute top-3 right-3 p-1.5 rounded-lg bg-slate-800/80 hover:bg-slate-800 text-slate-400 hover:text-red-400 border border-slate-700/60 transition-colors text-xs flex items-center gap-1"
              title="Очистить поле"
            >
              <Trash2 className="w-3.5 h-3.5" />
              <span>Очистить</span>
            </button>
          )}
        </div>

        {/* Tip & Action Buttons */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pt-1">
          <div className="flex items-center gap-1.5 text-xs text-slate-400">
            <AlertCircle className="w-4 h-4 text-amber-500 flex-shrink-0" />
            <span>
              Умный алгоритм выправит сокращения (Мск, Питер, Екб, Челны) и автоматически разделит груженые и порожние плечи.
            </span>
          </div>

          <div className="flex items-center gap-2 self-end sm:self-auto">
            <button
              type="submit"
              disabled={!rawText.trim() || isLoading}
              className="px-5 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 disabled:bg-slate-700 disabled:text-slate-500 text-slate-950 font-bold text-sm shadow-lg shadow-amber-500/20 hover:shadow-amber-500/30 transition-all flex items-center gap-2 cursor-pointer disabled:cursor-not-allowed"
            >
              {isLoading ? (
                <>
                  <div className="w-4 h-4 border-2 border-slate-950 border-t-transparent rounded-full animate-spin" />
                  <span>Обработка логистом...</span>
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4 text-slate-950" />
                  <span>Рассчитать пробег и составить таблицу</span>
                </>
              )}
            </button>
          </div>
        </div>
      </form>
    </div>
  );
};
