import React, { useState } from 'react';
import { CalculationSettings, TripSegment } from './types/logistics';
import { Header } from './components/Header';
import { SummaryCards } from './components/SummaryCards';
import { RawInputSection } from './components/RawInputSection';
import { TripTable } from './components/TripTable';
import { RouteMap } from './components/RouteMap';
import { EditSegmentModal } from './components/EditSegmentModal';
import { SettingsModal } from './components/SettingsModal';
import { HelpModal } from './components/HelpModal';
import { parseDriverRawNotes, SAMPLE_DATASETS } from './utils/textParser';
import { calculateRoadDistance } from './utils/geoUtils';

export default function App() {
  // Pre-seed with the realistic sample dataset so the user immediately sees working results
  const initialText = SAMPLE_DATASETS[0].rawText;
  const initialSegments = parseDriverRawNotes(initialText);

  const [rawText, setRawText] = useState<string>(initialText);
  const [segments, setSegments] = useState<TripSegment[]>(initialSegments);
  const [isLoading, setIsLoading] = useState<boolean>(false);

  // Settings
  const [settings, setSettings] = useState<CalculationSettings>({
    loadedRatePerKm: 85,
    emptyRatePerKm: 55,
    fuelConsumptionPer100Km: 32,
    fuelPricePerLiter: 68,
    currency: '₽',
  });

  // Modals state
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [isHelpOpen, setIsHelpOpen] = useState(false);
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [activeEditingSegment, setActiveEditingSegment] = useState<TripSegment | null>(null);

  // Process raw text: calls server-side AI if available, or falls back to smart local parser
  const handleProcessTrips = async (textToProcess: string) => {
    setIsLoading(true);
    try {
      // 1. Attempt server-side Gemini 3.8 Flash parsing
      const response = await fetch('/api/parse-trips', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ rawText: textToProcess }),
      });

      if (response.ok) {
        const result = await response.json();
        if (!result.fallback && result.data?.segments && Array.isArray(result.data.segments) && result.data.segments.length > 0) {
          const aiSegments: TripSegment[] = result.data.segments.map((s: any, idx: number) => {
            const distanceResult = calculateRoadDistance(s.startLocation, s.endLocation);
            return {
              id: `seg-ai-${idx}-${Date.now()}`,
              date: s.date || '',
              startLocation: s.startLocation,
              startOp: s.startOp || 'Загрузка',
              endLocation: s.endLocation,
              endOp: s.endOp || 'Разгрузка',
              tripType: s.tripType || 'Груженый',
              distanceKm: s.distanceKm && s.distanceKm > 0 ? s.distanceKm : distanceResult.distanceKm,
              notes: s.notes || '',
              startCoords: distanceResult.startCoords,
              endCoords: distanceResult.endCoords,
            };
          });

          setSegments(aiSegments);
          setIsLoading(false);
          return;
        }
      }
    } catch (err) {
      console.warn('Backend parsing unavailable, utilizing intelligent local parser', err);
    }

    // 2. Fallback to client-side smart parser
    const localParsed = parseDriverRawNotes(textToProcess);
    setSegments(localParsed);
    setIsLoading(false);
  };

  // Segment operations
  const handleUpdateSegment = (updated: TripSegment) => {
    setSegments((prev) => prev.map((s) => (s.id === updated.id ? updated : s)));
  };

  const handleDeleteSegment = (id: string) => {
    setSegments((prev) => prev.filter((s) => s.id !== id));
  };

  const handleAddSegment = () => {
    setActiveEditingSegment(null);
    setIsEditModalOpen(true);
  };

  const handleOpenEditModal = (segment: TripSegment) => {
    setActiveEditingSegment(segment);
    setIsEditModalOpen(true);
  };

  const handleSaveSegment = (segment: TripSegment) => {
    setSegments((prev) => {
      const exists = prev.some((s) => s.id === segment.id);
      if (exists) {
        return prev.map((s) => (s.id === segment.id ? segment : s));
      } else {
        return [...prev, segment];
      }
    });
  };

  const handleMoveSegment = (index: number, direction: 'up' | 'down') => {
    setSegments((prev) => {
      const updated = [...prev];
      const targetIndex = direction === 'up' ? index - 1 : index + 1;
      if (targetIndex < 0 || targetIndex >= updated.length) return prev;
      const temp = updated[index];
      updated[index] = updated[targetIndex];
      updated[targetIndex] = temp;
      return updated;
    });
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans">
      {/* App Header */}
      <Header
        onOpenSettings={() => setIsSettingsOpen(true)}
        onOpenHelp={() => setIsHelpOpen(true)}
        isAiAvailable={true}
        totalTripsCount={segments.length}
      />

      {/* Main Container */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6">
        {/* Top Summary Metric Cards */}
        <SummaryCards segments={segments} settings={settings} />

        {/* Raw Text Input Section */}
        <div className="no-print">
          <RawInputSection
            onProcess={handleProcessTrips}
            isLoading={isLoading}
            rawText={rawText}
            setRawText={setRawText}
          />
        </div>

        {/* Trips Table */}
        <TripTable
          segments={segments}
          onUpdateSegment={handleUpdateSegment}
          onDeleteSegment={handleDeleteSegment}
          onAddSegment={handleAddSegment}
          onMoveSegment={handleMoveSegment}
          onOpenEditModal={handleOpenEditModal}
        />

        {/* Interactive Route Map */}
        <div className="no-print">
          <RouteMap segments={segments} />
        </div>
      </main>

      {/* Modals */}
      <EditSegmentModal
        isOpen={isEditModalOpen}
        onClose={() => setIsEditModalOpen(false)}
        onSave={handleSaveSegment}
        initialSegment={activeEditingSegment}
      />

      <SettingsModal
        isOpen={isSettingsOpen}
        onClose={() => setIsSettingsOpen(false)}
        settings={settings}
        onSave={(newSettings) => setSettings(newSettings)}
      />

      <HelpModal isOpen={isHelpOpen} onClose={() => setIsHelpOpen(false)} />
    </div>
  );
}
