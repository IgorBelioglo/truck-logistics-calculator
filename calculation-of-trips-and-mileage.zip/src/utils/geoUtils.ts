import { OperationType, TripSegment, TripType } from '../types/logistics';

// Popular freight hubs database with coordinates
export interface CityInfo {
  name: string;
  aliases: string[];
  lat: number;
  lng: number;
}

export const CITIES_DATABASE: Record<string, CityInfo> = {
  moscow: {
    name: 'Москва',
    aliases: ['москва', 'мск', 'moscow', 'мск.', 'московская область', 'селятино', 'коледино', 'электростали', 'подольск', 'домодедово', 'ногинск', 'чехов', 'клин'],
    lat: 55.7558,
    lng: 37.6173,
  },
  spb: {
    name: 'Санкт-Петербург',
    aliases: ['санкт-петербург', 'спб', 'питер', 'saint petersburg', 'шушары', 'гатчина', 'колпино', 'всеволожск'],
    lat: 59.9343,
    lng: 30.3351,
  },
  nizhny: {
    name: 'Нижний Новгород',
    aliases: ['нижний новгород', 'нн', 'нижний', 'н.новгород', 'дзержинск', 'кстово', 'богородск'],
    lat: 56.3269,
    lng: 44.0059,
  },
  kazan: {
    name: 'Казань',
    aliases: ['казань', 'кзн', 'зеленодольск', 'татарстан'],
    lat: 55.7961,
    lng: 49.1064,
  },
  chelny: {
    name: 'Набережные Челны',
    aliases: ['набережные челны', 'челны', 'н.челны', 'нижнекамск', 'елабуга'],
    lat: 55.7436,
    lng: 52.4087,
  },
  samara: {
    name: 'Самара',
    aliases: ['самара', 'новокуйбышевск', 'чапаевск'],
    lat: 53.1959,
    lng: 50.1002,
  },
  tolyatti: {
    name: 'Тольятти',
    aliases: ['тольятти', 'тлт', 'жигулевск'],
    lat: 53.5078,
    lng: 49.4204,
  },
  ufa: {
    name: 'Уфа',
    aliases: ['уфа', 'башкортостан', 'стерлитамак', 'салават'],
    lat: 54.7388,
    lng: 55.9721,
  },
  ekb: {
    name: 'Екатеринбург',
    aliases: ['екатеринбург', 'екб', 'ебург', 'свердловск', 'пышма', 'березовский', 'первоуральск'],
    lat: 56.8389,
    lng: 60.6057,
  },
  chelyabinsk: {
    name: 'Челябинск',
    aliases: ['челябинск', 'члб', 'копейск', 'миасс', 'златоуст'],
    lat: 55.1644,
    lng: 61.4368,
  },
  perm: {
    name: 'Пермь',
    aliases: ['пермь', 'краснокамск', 'кунгур'],
    lat: 58.0105,
    lng: 56.2502,
  },
  tyumen: {
    name: 'Тюмень',
    aliases: ['тюмень', 'тмн'],
    lat: 57.1530,
    lng: 65.5343,
  },
  omsk: {
    name: 'Омск',
    aliases: ['омск'],
    lat: 54.9885,
    lng: 73.3242,
  },
  novosibirsk: {
    name: 'Новосибирск',
    aliases: ['новосибирск', 'нск', 'сиб', 'бердск', 'обь'],
    lat: 55.0084,
    lng: 82.9357,
  },
  krasnoyarsk: {
    name: 'Красноярск',
    aliases: ['красноярск', 'крск'],
    lat: 56.0153,
    lng: 92.8932,
  },
  rostov: {
    name: 'Ростов-на-Дону',
    aliases: ['ростов-на-дону', 'ростов', 'рнд', 'р-на-д', 'батайск', 'аксай', 'новочеркасск'],
    lat: 47.2357,
    lng: 39.7015,
  },
  krasnodar: {
    name: 'Краснодар',
    aliases: ['краснодар', 'крд', 'адыгейск', 'динская', 'славянск-на-кубани'],
    lat: 45.0355,
    lng: 38.9753,
  },
  sochi: {
    name: 'Сочи',
    aliases: ['сочи', 'адлер', 'лазаревское'],
    lat: 43.6028,
    lng: 39.7342,
  },
  novorossiysk: {
    name: 'Новороссийск',
    aliases: ['новороссийск', 'нврск', 'анапа', 'геленджик'],
    lat: 44.7154,
    lng: 37.7619,
  },
  voronezh: {
    name: 'Воронеж',
    aliases: ['воронеж', 'врн', 'семилуки', 'новая усмань'],
    lat: 51.6720,
    lng: 39.1843,
  },
  volgograd: {
    name: 'Волгоград',
    aliases: ['волгоград', 'влг', 'волжский'],
    lat: 48.7080,
    lng: 44.5133,
  },
  saratov: {
    name: 'Саратов',
    aliases: ['саратов', 'энгельс'],
    lat: 51.5406,
    lng: 46.0086,
  },
  yaroslavl: {
    name: 'Ярославль',
    aliases: ['ярославль', 'яр'],
    lat: 57.6261,
    lng: 39.8845,
  },
  tver: {
    name: 'Тверь',
    aliases: ['тверь'],
    lat: 56.8587,
    lng: 35.9176,
  },
  vladimir: {
    name: 'Владимир',
    aliases: ['владимир'],
    lat: 56.1290,
    lng: 40.4070,
  },
  ryazan: {
    name: 'Рязань',
    aliases: ['рязань'],
    lat: 54.6295,
    lng: 39.7425,
  },
  tula: {
    name: 'Тула',
    aliases: ['тула', 'новомосковск'],
    lat: 54.1961,
    lng: 37.6182,
  },
  kaluga: {
    name: 'Калуга',
    aliases: ['калуга', 'обнинск', 'ворсино'],
    lat: 54.5293,
    lng: 36.2754,
  },
  smolensk: {
    name: 'Смоленск',
    aliases: ['смоленск', 'красный'],
    lat: 54.7903,
    lng: 32.0504,
  },
  bryansk: {
    name: 'Брянск',
    aliases: ['брянск'],
    lat: 53.2521,
    lng: 34.3717,
  },
  orel: {
    name: 'Орёл',
    aliases: ['орел', 'орёл'],
    lat: 52.9651,
    lng: 36.0785,
  },
  kursk: {
    name: 'Курск',
    aliases: ['курск'],
    lat: 51.7304,
    lng: 36.1927,
  },
  belgorod: {
    name: 'Белгород',
    aliases: ['белгород', 'старый оскол'],
    lat: 50.5997,
    lng: 36.5983,
  },
  tambov: {
    name: 'Тамбов',
    aliases: ['тамбов', 'мичуринск'],
    lat: 52.7317,
    lng: 41.4433,
  },
  penza: {
    name: 'Пенза',
    aliases: ['пенза', 'заречный'],
    lat: 53.2001,
    lng: 45.0160,
  },
  ulyanovsk: {
    name: 'Ульяновск',
    aliases: ['ульяновск', 'димитровград'],
    lat: 54.3142,
    lng: 48.4031,
  },
  orenburg: {
    name: 'Оренбург',
    aliases: ['оренбург', 'орск'],
    lat: 51.7727,
    lng: 55.0988,
  },
  kirov: {
    name: 'Киров',
    aliases: ['киров', 'вятка'],
    lat: 58.6035,
    lng: 49.6679,
  },
  izhevsk: {
    name: 'Ижевск',
    aliases: ['ижевск', 'удмуртия'],
    lat: 56.8524,
    lng: 53.2045,
  },
  vologda: {
    name: 'Вологда',
    aliases: ['вологда'],
    lat: 59.2205,
    lng: 39.8915,
  },
  cherepovets: {
    name: 'Череповец',
    aliases: ['череповец', 'северсталь'],
    lat: 59.1323,
    lng: 37.9042,
  },
  ivanovo: {
    name: 'Иваново',
    aliases: ['иваново', 'шуя'],
    lat: 56.9972,
    lng: 40.9714,
  },
  kostroma: {
    name: 'Кострома',
    aliases: ['кострома'],
    lat: 57.7679,
    lng: 40.9269,
  },
  velikiy_novgorod: {
    name: 'Великий Новгород',
    aliases: ['великий новгород', 'новгород'],
    lat: 58.5215,
    lng: 31.2755,
  },
  pskov: {
    name: 'Псков',
    aliases: ['псков'],
    lat: 57.8193,
    lng: 28.3318,
  },
  stavropol: {
    name: 'Ставрополь',
    aliases: ['ставрополь', 'михайловск'],
    lat: 45.0428,
    lng: 41.9734,
  },
  pyatigorsk: {
    name: 'Пятигорск',
    aliases: ['пятигорск', 'кмв', 'минеральные воды', 'минводы', 'ессентуки', 'кисловодск'],
    lat: 44.0486,
    lng: 43.0594,
  },
  astrakhan: {
    name: 'Астрахань',
    aliases: ['астрахань'],
    lat: 46.3497,
    lng: 48.0408,
  },
  minsk: {
    name: 'Минск',
    aliases: ['минск', 'беларусь'],
    lat: 53.9006,
    lng: 27.5590,
  },
  brest: {
    name: 'Брест',
    aliases: ['брест'],
    lat: 52.0976,
    lng: 23.7341,
  },
  gomel: {
    name: 'Гомель',
    aliases: ['гомель'],
    lat: 52.4345,
    lng: 30.9754,
  },
  astana: {
    name: 'Астана',
    aliases: ['астана', 'нур-султан', 'казахстан'],
    lat: 51.1694,
    lng: 71.4491,
  },
  almaty: {
    name: 'Алматы',
    aliases: ['алматы', 'алма-ата'],
    lat: 43.2220,
    lng: 76.8512,
  },
};

// Known high-precision road distances (km) for major trunk corridors
const PRECISE_HIGHWAY_DISTANCES: Record<string, number> = {
  'москва-санкт-петербург': 705,
  'санкт-петербург-москва': 705,
  'москва-нижний новгород': 420,
  'нижний новгород-москва': 420,
  'москва-казань': 820,
  'казань-москва': 820,
  'москва-екатеринбург': 1780,
  'екатеринбург-москва': 1780,
  'москва-ростов-на-дону': 1080,
  'ростов-на-дону-москва': 1080,
  'москва-краснодар': 1340,
  'краснодар-москва': 1340,
  'москва-воронеж': 520,
  'воронеж-москва': 520,
  'москва-самара': 1050,
  'самара-москва': 1050,
  'москва-уфа': 1350,
  'уфа-москва': 1350,
  'москва-тверь': 175,
  'тверь-москва': 175,
  'тверь-санкт-петербург': 530,
  'санкт-петербург-тверь': 530,
  'москва-ярославль': 260,
  'ярославль-москва': 260,
  'москва-тула': 180,
  'тула-москва': 180,
  'москва-калуга': 185,
  'калуга-москва': 185,
  'москва-смоленск': 390,
  'смоленск-москва': 390,
  'москва-рязань': 195,
  'рязань-москва': 195,
  'москва-владимир': 185,
  'владимир-москва': 185,
  'владимир-нижний новгород': 235,
  'нижний новгород-владимир': 235,
  'нижний новгород-казань': 395,
  'казань-нижний новгород': 395,
  'казань-набережные челны': 240,
  'набережные челны-казань': 240,
  'казань-уфа': 525,
  'уфа-казань': 525,
  'казань-самара': 360,
  'самара-казань': 360,
  'самара-тольятти': 90,
  'тольятти-самара': 90,
  'самара-уфа': 460,
  'уфа-самара': 460,
  'уфа-челябинск': 420,
  'челябинск-уфа': 420,
  'екатеринбург-челябинск': 210,
  'челябинск-екатеринбург': 210,
  'екатеринбург-пермь': 360,
  'пермь-екатеринбург': 360,
  'екатеринбург-тюмень': 325,
  'тюмень-екатеринбург': 325,
  'тюмень-омск': 630,
  'омск-тюмень': 630,
  'омск-новосибирск': 660,
  'новосибирск-омск': 660,
  'новосибирск-красноярск': 790,
  'красноярск-новосибирск': 790,
  'воронеж-ростов-на-дону': 565,
  'ростов-на-дону-воронеж': 565,
  'ростов-на-дону-краснодар': 275,
  'краснодар-ростов-на-дону': 275,
  'краснодар-сочи': 295,
  'сочи-краснодар': 295,
  'краснодар-новороссийск': 150,
  'новороссийск-краснодар': 150,
  'ростов-на-дону-волгоград': 470,
  'волгоград-ростов-на-дону': 470,
  'волгоград-саратов': 380,
  'саратов-волгоград': 380,
  'саратов-самара': 430,
  'самара-саратов': 430,
  'москва-минск': 715,
  'минск-москва': 715,
  'минск-брест': 350,
  'брест-минск': 350,
};

// Find matching city in database
export function findCity(raw: string): CityInfo | null {
  if (!raw) return null;
  const clean = raw.toLowerCase().trim()
    .replace(/^(г\.|гор\.|город|пос\.|поселок|п\.|д\.|деревня|ст\.|территория|с\.|село)\s+/i, '')
    .trim();

  // 1. Direct match with aliases
  for (const city of Object.values(CITIES_DATABASE)) {
    if (city.name.toLowerCase() === clean) return city;
    for (const alias of city.aliases) {
      if (clean === alias || clean.startsWith(alias + ' ') || clean.includes(' ' + alias) || clean.includes(alias)) {
        return city;
      }
    }
  }

  // 2. Fuzzy / partial match
  for (const city of Object.values(CITIES_DATABASE)) {
    const cName = city.name.toLowerCase();
    if (clean.includes(cName) || cName.includes(clean)) {
      return city;
    }
  }

  return null;
}

// Calculate great circle distance (Haversine) in km
function haversineDistance(lat1: number, lon1: number, lat2: number, lon2: number): number {
  const R = 6371; // Earth's radius in km
  const dLat = ((lat2 - lat1) * Math.PI) / 180;
  const dLon = ((lon2 - lon1) * Math.PI) / 180;
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos((lat1 * Math.PI) / 180) *
      Math.cos((lat2 * Math.PI) / 180) *
      Math.sin(dLon / 2) *
      Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return R * c;
}

/**
 * Calculates road distance between two locations in km.
 * Checks known highway tables first, then uses road-tortuosity factor (1.24 - 1.28) over Haversine.
 */
export function calculateRoadDistance(start: string, end: string): { distanceKm: number; startCoords?: [number, number]; endCoords?: [number, number]; normalizedStart: string; normalizedEnd: string } {
  const cityA = findCity(start);
  const cityB = findCity(end);

  const normalizedStart = cityA ? cityA.name : start.trim();
  const normalizedEnd = cityB ? cityB.name : end.trim();

  if (normalizedStart.toLowerCase() === normalizedEnd.toLowerCase()) {
    return {
      distanceKm: 25, // intra-city run between industrial zones / terminals
      startCoords: cityA ? [cityA.lat, cityA.lng] : undefined,
      endCoords: cityB ? [cityB.lat, cityB.lng] : undefined,
      normalizedStart,
      normalizedEnd,
    };
  }

  // Check precise corridor table
  const key = `${normalizedStart.toLowerCase()}-${normalizedEnd.toLowerCase()}`;
  if (PRECISE_HIGHWAY_DISTANCES[key]) {
    return {
      distanceKm: PRECISE_HIGHWAY_DISTANCES[key],
      startCoords: cityA ? [cityA.lat, cityA.lng] : undefined,
      endCoords: cityB ? [cityB.lat, cityB.lng] : undefined,
      normalizedStart,
      normalizedEnd,
    };
  }

  // If both cities are located in our coordinate DB
  if (cityA && cityB) {
    const directKm = haversineDistance(cityA.lat, cityA.lng, cityB.lat, cityB.lng);
    // Road winding coefficient: usually 1.22 for highways up to 1.30 for regional roads
    const roadFactor = directKm > 1000 ? 1.22 : 1.27;
    const roadKm = Math.round(directKm * roadFactor);
    return {
      distanceKm: Math.max(15, roadKm),
      startCoords: [cityA.lat, cityA.lng],
      endCoords: [cityB.lat, cityB.lng],
      normalizedStart,
      normalizedEnd,
    };
  }

  // Fallback heuristic if unknown town: approximate default leg
  return {
    distanceKm: 150,
    normalizedStart,
    normalizedEnd,
  };
}

/**
 * Generates the clean Markdown table exactly as requested in the user prompt:
 * Columns:
 * - Дата
 * - Начальная точка (Откуда / Адрес)
 * - Тип операции (Загрузка / Разгрузка)
 * - Конечная точка (Куда / Адрес)
 * - Тип операции (Загрузка / Разгрузка)
 * - Тип рейса (Груженый / Порожний)
 * - Расстояние (км)
 * In the end: ИТОГО:
 * - Общий пробег за месяц (км)
 * - Пробег под грузом (км)
 * - Порожний пробег (км)
 */
export function generateMarkdownReport(segments: TripSegment[]): string {
  const loadedKm = segments
    .filter((s) => s.tripType === 'Груженый')
    .reduce((acc, curr) => acc + (curr.distanceKm || 0), 0);

  const emptyKm = segments
    .filter((s) => s.tripType === 'Порожний')
    .reduce((acc, curr) => acc + (curr.distanceKm || 0), 0);

  const totalKm = loadedKm + emptyKm;

  let md = '| Дата | Начальная точка (Откуда / Адрес) | Тип операции | Конечная точка (Куда / Адрес) | Тип операции | Тип рейса | Расстояние (км) |\n';
  md += '| :--- | :--- | :--- | :--- | :--- | :--- | :---: |\n';

  segments.forEach((s) => {
    const dateStr = s.date || '—';
    md += `| ${dateStr} | ${s.startLocation} | ${s.startOp} | ${s.endLocation} | ${s.endOp} | ${s.tripType} | ${s.distanceKm} |\n`;
  });

  md += `| **ИТОГО** | | | | | | **${totalKm}** |\n\n`;
  md += '### ИТОГОВЫЕ ЦИФРЫ ЗА МЕСЯЦ:\n';
  md += `- **Общий пробег за месяц:** ${totalKm.toLocaleString('ru-RU')} км\n`;
  md += `- **Пробег под грузом:** ${loadedKm.toLocaleString('ru-RU')} км (${totalKm > 0 ? ((loadedKm / totalKm) * 100).toFixed(1) : 0}%)\n`;
  md += `- **Порожний (холостой) пробег:** ${emptyKm.toLocaleString('ru-RU')} км (${totalKm > 0 ? ((emptyKm / totalKm) * 100).toFixed(1) : 0}%)\n`;

  return md;
}

/**
 * Generates TSV (Tab Separated Values) for instant copy & paste into Excel or Google Sheets.
 */
export function generateTsvReport(segments: TripSegment[]): string {
  const loadedKm = segments
    .filter((s) => s.tripType === 'Груженый')
    .reduce((acc, curr) => acc + (curr.distanceKm || 0), 0);

  const emptyKm = segments
    .filter((s) => s.tripType === 'Порожний')
    .reduce((acc, curr) => acc + (curr.distanceKm || 0), 0);

  const totalKm = loadedKm + emptyKm;

  let tsv = 'Дата\tНачальная точка (Откуда / Адрес)\tТип операции\tКонечная точка (Куда / Адрес)\tТип операции\tТип рейса\tРасстояние (км)\n';

  segments.forEach((s) => {
    tsv += `${s.date || ''}\t${s.startLocation}\t${s.startOp}\t${s.endLocation}\t${s.endOp}\t${s.tripType}\t${s.distanceKm}\n`;
  });

  tsv += `ИТОГО\t\t\t\t\t\t${totalKm}\n`;
  tsv += `\nИтоговые показатели:\n`;
  tsv += `Общий пробег (км)\t${totalKm}\n`;
  tsv += `Пробег под грузом (км)\t${loadedKm}\n`;
  tsv += `Порожний пробег (км)\t${emptyKm}\n`;

  return tsv;
}

/**
 * Generates downloadable CSV content with UTF-8 BOM so Excel opens it with proper Russian letters.
 */
export function generateCsvReport(segments: TripSegment[]): string {
  const loadedKm = segments
    .filter((s) => s.tripType === 'Груженый')
    .reduce((acc, curr) => acc + (curr.distanceKm || 0), 0);

  const emptyKm = segments
    .filter((s) => s.tripType === 'Порожний')
    .reduce((acc, curr) => acc + (curr.distanceKm || 0), 0);

  const totalKm = loadedKm + emptyKm;

  const lines = [
    'Дата;Начальная точка (Откуда / Адрес);Тип операции;Конечная точка (Куда / Адрес);Тип операции;Тип рейса;Расстояние (км)',
    ...segments.map(
      (s) =>
        `"${s.date || ''}";"${s.startLocation}";"${s.startOp}";"${s.endLocation}";"${s.endOp}";"${s.tripType}";${s.distanceKm}`
    ),
    `"ИТОГО";"";"";"";"";"";${totalKm}`,
    '',
    `"Общий пробег за месяц (км)";${totalKm}`,
    `"Пробег под грузом (км)";${loadedKm}`,
    `"Порожний пробег (км)";${emptyKm}`,
  ];

  // \uFEFF is UTF-8 Byte Order Mark for Microsoft Excel
  return '\uFEFF' + lines.join('\r\n');
}
