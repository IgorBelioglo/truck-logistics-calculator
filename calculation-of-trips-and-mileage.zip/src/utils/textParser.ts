import { OperationType, TripSegment, TripType } from '../types/logistics';
import { calculateRoadDistance, findCity } from './geoUtils';

export interface SampleDataset {
  id: string;
  title: string;
  badge: string;
  description: string;
  rawText: string;
}

export const SAMPLE_DATASETS: SampleDataset[] = [
  {
    id: 'sample-telegram-driver',
    title: 'Записи из блокнота/Telegram водителя',
    badge: 'С опечатками и холостыми',
    description: 'Реалистичный путевой журнал за май: Москва -> Тверь -> Клин -> Казань -> Челны -> Самара -> Москва с холостыми перегонами.',
    rawText: `02.05.2024 Мск склад Селятино (З) — Тверь РЦ Магнит (Р)
03.05.2024 Тверь (Р) — Клин стекольный з-д (З) (пустой перегон)
04.05.2024 Клин (З) — Казань промзона Север (Р)
07.05.2024 Казань (Р) — Набережные Челны Камаз (З) (порожняком за запчастями)
08.05.2024 Набережные Челны (З) — Самара распределительный центр (Р)
11.05.2024 Самара (Р) — Тольятти АвтоВАЗ (З) холостой
12.05.2024 Тольятти (З) — Москва терминал Южные Врата (Р)`,
  },
  {
    id: 'sample-messy-voice',
    title: 'Голосовые заметки / Сырой текст без формата',
    badge: 'Сырой текст',
    description: 'Неструктурированный текст водителя с сокращениями названий городов (СПб, Екб, НН, Врн).',
    rawText: `15 мая выгрузился в Питере на Шушарах. 
Оттуда пустой перегон на Великий Новгород на погрузку фанеры.
Загрузился в Новгороде до Нижнего Новгорода, сдал 18 мая.
19 мая перегон порожний в Дзержинск на химзавод.
Там загрузка бытовой химии на Екатеринбург. Доехал и разгрузился в Екб 23 мая.
Из Екатеринбурга холостой ход на Челябинск за металлопрокатом.
Челябинск погрузка — разгрузка в Самаре 27 мая.`,
  },
  {
    id: 'sample-ural-south',
    title: 'Кольцевой рейс Центр — Урал — Юг',
    badge: 'Дальний рейс',
    description: 'Большой рейс через Поволжье, Урал и Кавказ/Юг с полным циклом погрузок и выгрузок.',
    rawText: `01.06 Москва (Загрузка) -> Воронеж (Разгрузка)
03.06 Воронеж (Разгрузка) -> Ростов-на-Дону (Загрузка) (порожний)
04.06 Ростов-на-Дону (Загрузка) -> Краснодар (Разгрузка)
06.06 Краснодар (Разгрузка) -> Новороссийск (Загрузка) (холостой)
07.06 Новороссийск (Загрузка) -> Волгоград (Разгрузка)
10.06 Волгоград (Разгрузка) -> Саратов (Загрузка) (порожний)
11.06 Саратов (Загрузка) -> Москва (Разгрузка)`,
  },
];

/**
 * Intelligent client-side parser for driver records.
 * Can parse structured formats ("A (З) -> B (Р)"), bullet points, lines with dates, or continuous narration.
 */
export function parseDriverRawNotes(text: string): TripSegment[] {
  if (!text || !text.trim()) return [];

  const lines = text
    .split('\n')
    .map((l) => l.trim())
    .filter((l) => l.length > 0);

  const segments: TripSegment[] = [];

  // Regex patterns for line parsing
  // Matches dates: 02.05.2024, 02.05, 2 мая, 2024-05-02
  const dateRegex = /(\d{1,2}[./-]\d{1,2}(?:[./-]\d{2,4})?|\d{1,2}\s+(?:янв|фев|мар|апр|май|мая|июн|июл|авг|сен|окт|ноя|дек)[а-я]*)/i;

  // Check if text is written as arrow/dash delimited pairs per line: "A -> B" or "A — B"
  const pairDelimRegex = /(?:—|-->|->|—>|-|–|до|в направлении)/;

  for (let i = 0; i < lines.length; i++) {
    const rawLine = lines[i];

    // Check for empty/deadhead keywords
    const isEmptyIndicator = /(?:порожн|холост|пустой|порожняк|без груза|подача|холостой)/i.test(rawLine);

    // Extract date if present
    const dateMatch = rawLine.match(dateRegex);
    const date = dateMatch ? dateMatch[1] : '';

    // Strip out the date and noise for route extraction
    let cleanLine = rawLine.replace(dateRegex, '').replace(/^\d+[\).]\s*/, '').trim();

    // Check if line contains a delimiter separating Origin and Destination
    if (pairDelimRegex.test(cleanLine)) {
      const parts = cleanLine.split(pairDelimRegex);
      if (parts.length >= 2) {
        let originRaw = parts[0].trim();
        let destRaw = parts.slice(1).join(' ').trim();

        // Detect operations
        let originOp: OperationType = 'Загрузка';
        let destOp: OperationType = 'Разгрузка';

        if (/\b(?:р|разгрузка|выгрузка|выгрузился|сдал|разгрузились)\b/i.test(originRaw) || /\(р\)/i.test(originRaw)) {
          originOp = 'Разгрузка';
        }
        if (/\b(?:з|загрузка|погрузка|загрузился|взял|загрузились)\b/i.test(destRaw) || /\(з\)/i.test(destRaw)) {
          destOp = 'Загрузка';
        }

        // Clean annotations from city names
        const cleanOrigin = cleanCityString(originRaw);
        const cleanDest = cleanCityString(destRaw);

        // Determine trip type:
        // If origin is Разгрузка and destination is Загрузка -> naturally Порожний!
        // Or if explicitly marked as empty/порожний
        let tripType: TripType = 'Груженый';
        if (isEmptyIndicator || (originOp === 'Разгрузка' && destOp === 'Загрузка')) {
          tripType = 'Порожний';
          originOp = 'Разгрузка';
          destOp = 'Загрузка';
        }

        const distanceCalc = calculateRoadDistance(cleanOrigin, cleanDest);

        segments.push({
          id: `seg-${Date.now()}-${Math.random().toString(36).substr(2, 6)}`,
          date,
          startLocation: distanceCalc.normalizedStart || cleanOrigin,
          startOp: originOp,
          endLocation: distanceCalc.normalizedEnd || cleanDest,
          endOp: destOp,
          tripType,
          distanceKm: distanceCalc.distanceKm,
          startCoords: distanceCalc.startCoords,
          endCoords: distanceCalc.endCoords,
        });
        continue;
      }
    }
  }

  // If line-by-line delimiter didn't yield segments, let's try narrative extraction
  if (segments.length === 0) {
    const narrativeSegments = parseNarrativeText(text);
    if (narrativeSegments.length > 0) {
      return narrativeSegments;
    }
  }

  return segments;
}

function cleanCityString(str: string): string {
  return str
    .replace(/\(.*?\)/g, '') // remove parens like (З), (Р), (пустой)
    .replace(/\[.*?\]/g, '')
    .replace(/(?:порожн|холост|пустой|перегон|склад|рц|завод|терминал|промзона|х\.|п\.|г\.|гор\.)[а-я]*/gi, '')
    .replace(/[—–\-–>]/g, '')
    .replace(/[\d,]+(?:\s*км)?/gi, '')
    .trim();
}

/**
 * Parses free text stories like: "выгрузился в Твери, поехал в Клин загрузился до Казани..."
 */
function parseNarrativeText(text: string): TripSegment[] {
  // Split into sentences or clauses
  const sentences = text.split(/[.;\n]+/).map((s) => s.trim()).filter((s) => s.length > 3);
  const segments: TripSegment[] = [];

  for (let i = 0; i < sentences.length; i++) {
    const sentence = sentences[i];
    const words = sentence.toLowerCase().split(/\s+/);

    // Look for cities mentioned
    const mentionedCities: { name: string; index: number }[] = [];
    words.forEach((w, idx) => {
      const city = findCity(w.replace(/[^a-zа-яё]/gi, ''));
      if (city && !mentionedCities.some((c) => c.name === city.name)) {
        mentionedCities.push({ name: city.name, index: idx });
      }
    });

    if (mentionedCities.length >= 2) {
      const start = mentionedCities[0].name;
      const end = mentionedCities[1].name;
      const isEmpty = /(?:пустой|холост|порожн|перегон)/i.test(sentence);

      const distanceCalc = calculateRoadDistance(start, end);
      segments.push({
        id: `seg-narrative-${i}-${Date.now()}`,
        date: '',
        startLocation: start,
        startOp: isEmpty ? 'Разгрузка' : 'Загрузка',
        endLocation: end,
        endOp: isEmpty ? 'Загрузка' : 'Разгрузка',
        tripType: isEmpty ? 'Порожний' : 'Груженый',
        distanceKm: distanceCalc.distanceKm,
        startCoords: distanceCalc.startCoords,
        endCoords: distanceCalc.endCoords,
      });
    }
  }

  return segments;
}
