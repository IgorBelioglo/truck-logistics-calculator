import express from 'express';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';
import { GoogleGenAI, Type } from '@google/genai';
import { createServer as createViteServer } from 'vite';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;

app.use(express.json({ limit: '10mb' }));

// Initialize Gemini SDK with User-Agent telemetry as required
const apiKey = process.env.GEMINI_API_KEY;
let ai: GoogleGenAI | null = null;

if (apiKey) {
  ai = new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

// API endpoint for AI-assisted trip analysis and normalization
app.post('/api/parse-trips', async (req, res) => {
  try {
    const { rawText } = req.body;
    if (!rawText || typeof rawText !== 'string' || !rawText.trim()) {
      return res.status(400).json({ error: 'Текст для анализа пуст' });
    }

    if (!ai) {
      // Fallback: If no API key is provided, indicate client fallback
      return res.json({
        fallback: true,
        message: 'Gemini API key is not configured, using built-in offline logistics engine.',
      });
    }

    const systemInstruction = `Ты — ведущий логист-диспетчер и бухгалтер грузоперевозок для водителей-дальнобойщиков.
Твоя задача — извлечь из сырых путевых заметок водителя (или его брата/диспетчера) все последовательные участки рейсов за месяц.
Специфика:
1. Выправь все сокращения и опечатки в названиях населенных пунктов (например: "Мск" -> "Москва", "Питер" / "СПб" -> "Санкт-Петербург", "НН" -> "Нижний Новгород", "Екб" -> "Екатеринбург", "Челны" -> "Набережные Челны", "РнД" -> "Ростов-на-Дону", "Врн" -> "Воронеж", "Крд" -> "Краснодар", "Шушары" -> "Санкт-Петербург (Шушары)", "Селятино" -> "Москва (Селятино)").
2. Определи тип операции в начальной и конечной точке (строго 'Загрузка' или 'Разгрузка').
3. Определи тип рейса:
   - 'Груженый' (когда везет груз от погрузки к выгрузке, Загрузка -> Разгрузка)
   - 'Порожний' (холостой перегон / подача пустой машины от точки разгрузки к следующей точке погрузки, Разгрузка -> Загрузка)
4. Рассчитай точное расстояние по автодорогам (км) между точками.
5. Если указана дата, сохрани ее в понятном формате (например, 02.05 или 02.05.2024).`;

    const prompt = `Проанализируй следующие записи о рейсах дальнобойщика и верни структурированный список всех отрезков пути:\n\n${rawText}`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: prompt,
      config: {
        systemInstruction,
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            segments: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  date: { type: Type.STRING, description: 'Дата рейса если найдена, иначе пустая строка' },
                  startLocation: { type: Type.STRING, description: 'Исправленное название начальной точки с регионом или объектом' },
                  startOp: { type: Type.STRING, enum: ['Загрузка', 'Разгрузка'], description: 'Тип операции в точке отправления' },
                  endLocation: { type: Type.STRING, description: 'Исправленное название конечной точки' },
                  endOp: { type: Type.STRING, enum: ['Загрузка', 'Разгрузка'], description: 'Тип операции в точке прибытия' },
                  tripType: { type: Type.STRING, enum: ['Груженый', 'Порожний'], description: 'Тип рейса' },
                  distanceKm: { type: Type.NUMBER, description: 'Точное расстояние по автодорогам в километрах' },
                  notes: { type: Type.STRING, description: 'Дополнительные примечания (характер груза, завод, особенности)' },
                },
                required: ['startLocation', 'startOp', 'endLocation', 'endOp', 'tripType', 'distanceKm'],
              },
            },
            summaryNotes: {
              type: Type.STRING,
              description: 'Краткое резюме логиста по маршруту за месяц',
            },
          },
          required: ['segments'],
        },
      },
    });

    const outputText = response.text?.trim() || '{}';
    const parsedData = JSON.parse(outputText);

    return res.json({
      fallback: false,
      data: parsedData,
    });
  } catch (error: any) {
    console.error('Gemini parsing note:', error?.message || error);
    return res.json({
      fallback: true,
      error: error?.message || 'Временная недоступность нейросети, переключение на локальный движок',
    });
  }
});

// Mount Vite or serve static files
async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (_req, res) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server listening on http://0.0.0.0:${PORT}`);
  });
}

startServer();
